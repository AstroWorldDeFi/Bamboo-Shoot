using UnityEngine;
using System.Collections;

public class MoveCamera : MonoBehaviour
{

    float speed;

    [Header("OrbitCamera")]
    private Vector3 lastMouse = new Vector3(255, 255, 255); //kind of in the middle of the screen, rather than at the top (play)
    public float camSens = 0.15f; //How sensitive it with mouse


    public float speedH = 2.0f;
    public float speedV = 2.0f;

    private float yaw = 0.0f;
    private float pitch = 0.0f;

    [Header("Jump")]
    public float jumpHeight = 7f;
    public bool isGrounded;
    public float NumberJumps = 0f;
    public float MaxJumps = 2;
    private Rigidbody rb;

    public float mouseSensitivity = 100.0f;
    public float clampAngle = 80.0f;

    private float rotY = 180f; // rotation around the up/y axis
    private float rotX = 0.0f; // rotation around the right/x axis

    Vector3 speedToMove;
    Vector3 v3= new Vector3 (0,0,0);
    bool gameStarted =false;

    void Start()
    {
        StartCoroutine("StartGame");
        rb = GetComponent<Rigidbody>();


    }

    IEnumerator StartGame()
    {
        yield return new WaitForSeconds(1.0f);
        gameStarted = true;
    }

    void Update()
    {
        if (gameStarted == true)
        {
            float mouseX = Input.GetAxis("Mouse X");
            float mouseY = -Input.GetAxis("Mouse Y");

            rotY += mouseX * mouseSensitivity * Time.deltaTime;
            rotX += mouseY * mouseSensitivity * Time.deltaTime;

            rotX = Mathf.Clamp(rotX, -clampAngle, clampAngle);

            Quaternion localRotation = Quaternion.Euler(rotX, rotY, 0.0f);
            transform.rotation = localRotation;
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = true;
        }



        //Jump

        if (NumberJumps > MaxJumps - 1)
        {
            isGrounded = false;
        }

        if (isGrounded)
        {
            if (Input.GetKeyDown("space"))
            {
                rb.AddForce(Vector3.up * jumpHeight, ForceMode.Impulse);
                NumberJumps += 1;
            }
        }
    }

    void OnCollisionEnter(Collision other)
    {
        isGrounded = true;
        NumberJumps = 0;
    }



    void FixedUpdate()
    {
        speed = 11;
        if (Input.GetKey(KeyCode.R))
        {
            v3 = transform.forward * 22;
            v3.y = rb.velocity.y;
            rb.velocity = v3; 
        }



        if (Input.GetKey(KeyCode.W))
        {
            v3 = transform.forward * speed;
            v3.y = rb.velocity.y;
            rb.velocity = v3;

            if (Input.GetKey(KeyCode.A))
            {
                v3 += -transform.right * 2;
                v3.y = rb.velocity.y;
                rb.velocity = v3;
            }
            if (Input.GetKey(KeyCode.D))
            {
                v3 += transform.right * 2;
                v3.y = rb.velocity.y;
                rb.velocity = v3;
            }
        }
        else
        {
            if (Input.GetKey(KeyCode.A))
            {
                v3 = -transform.right * speed;
                v3.y = rb.velocity.y;
                rb.velocity = v3;
            }
            if (Input.GetKey(KeyCode.D))
            {
                v3 = transform.right * speed;
                v3.y = rb.velocity.y;
                rb.velocity = v3;
            }
            if (Input.GetKey(KeyCode.S))
            {
                v3 = -transform.forward * speed;
                v3.y = rb.velocity.y;
                rb.velocity = v3;
            }
        }




    }



}
